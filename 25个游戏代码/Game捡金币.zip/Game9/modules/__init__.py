'''初始化'''
from .hero import Hero
from .food import Food
from .endinterface import showEndGameInterface