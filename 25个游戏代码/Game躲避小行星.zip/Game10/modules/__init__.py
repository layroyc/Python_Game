'''初始化'''
from .sprites import Bullet, Ship, Asteroid
from .interfaces import StartInterface, EndInterface