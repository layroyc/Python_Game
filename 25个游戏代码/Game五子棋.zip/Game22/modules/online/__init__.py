'''初始化'''
from .server import gobangSever
from .client import gobangClient
from .playOnline import playOnlineUI