'''初始化'''
from .aiGobang import aiGobang
from .playWithAI import playWithAIUI