'''初始化'''
from .mole import Mole
from .hammer import Hammer