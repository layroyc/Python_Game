'''初始化'''
from .food import Apple
from .snake import Snake
from .endInterface import endInterface
from .utils import drawGameGrid, showScore