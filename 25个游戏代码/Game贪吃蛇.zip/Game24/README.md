# Introduction
https://mp.weixin.qq.com/s/YdRLYz4BnfgRZMYqKvDnRA

# Environment
```
OS: Windows10
Python: Python3.5+(have installed necessary dependencies)
```

# Usage
```
Step1:
pip install -r requirements.txt
Step2:
run "python Game24.py"
```

# Game Display
![giphy](demonstration/running.gif)