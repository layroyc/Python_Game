'''初始化'''
from .shapes import tetrisShape
from .gameboard import InnerBoard, ExternalBoard, SidePanel