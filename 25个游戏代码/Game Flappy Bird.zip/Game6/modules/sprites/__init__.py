'''初始化'''
from .Bird import Bird
from .Pipe import Pipe