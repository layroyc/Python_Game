'''初始化'''
from .interfaces import StartInterface, EndInterface, GamingInterface, PauseInterface, ChoiceInterface