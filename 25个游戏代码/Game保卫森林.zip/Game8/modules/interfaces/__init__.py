'''初始化'''
from .end import EndInterface
from .start import StartInterface
from .pause import PauseInterface
from .choice import ChoiceInterface
from .gaming import GamingInterface