'''配置文件'''
import os


'''一些颜色'''
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (50, 250, 5)
RED = (255, 0, 0)
'''FPS'''
FPS = 60
'''背景音乐'''
BGMPATH = os.path.join(os.getcwd(), 'resources/bgm.mp3')
'''屏幕大小'''
SCREENSIZE = (800, 600)