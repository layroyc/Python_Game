'''初始化'''
from .utils import showLife, showText, endInterface
from .sprites import aircraftSprite, ufoSprite, enemySprite, myBulletSprite, enemyBulletSprite